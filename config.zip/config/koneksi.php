<?php
$hostname = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'ukk_galerifoto1';

$koneksi = mysqli_connect($hostname,$userdb,$passdb,$namedb);

?>